# xv3_packages

to 

to install xv3_pkg : xv3 install <pkg> 

this is xv3 packages its Package Manager Created at 8/16/2025 by  name:Ahmed Walled Abdalhafez Saad Ali|age:24/10/2013


To configure xv3 type in the terminal: 
chmod +x ./build.sh && ./build.sh 

