#!/bin/sh

# Script name: install.sh
# Purpose: Install xv3 tool to system

# Check if script is run as root
if [ "$(id -u)" -ne 0 ]; then
    echo "This script must be run as root (use sudo)"
    exit 1
fi

# Check if xv3 exists in current directory
if [ ! -f "xv3" ]; then
    echo "Error: xv3 file not found in current directory!"
    exit 1
fi

# Remove old version if exists in /usr/local/bin/
if [ -f "/usr/local/bin/xv3" ]; then
    echo "Removing old version from /usr/local/bin/"
    rm -f /usr/local/bin/xv3
fi

# Remove xv3.py if exists in /usr/local/bin/ (for cleanup)
if [ -f "/usr/local/bin/xv3.py" ]; then
    echo "Removing xv3.py from /usr/local/bin/"
    rm -f /usr/local/bin/xv3.py
fi

# Make xv3 executable
echo "Making xv3 executable..."
chmod +x xv3

# Copy to /usr/local/bin
echo "Installing xv3 to /usr/local/bin/"
cp xv3 /usr/local/bin/


echo "______________________________________________________________________________________________________________"
echo "|you now can install for xv3 example : xv3 install <example_pkg> | with sudo : sudo xv3 install <example_pkg>|"
echo "|_______________________________Don't forget to read the LICENSE.md file_____________________________________|"
